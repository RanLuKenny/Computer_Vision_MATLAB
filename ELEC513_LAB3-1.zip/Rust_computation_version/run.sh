make


echo "Rng123!" | sudo -S insmod ./target/kernel/kmod.ko
echo "[INFO] Inserted kernel mod."

echo "[INFO] Calculate."


echo "Rng123!" | sudo -S rmmod kmod.ko
echo "[INFO] Cleanup."

