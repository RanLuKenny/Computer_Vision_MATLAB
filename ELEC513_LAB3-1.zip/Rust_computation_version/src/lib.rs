//! A simple kernel module in Rust
#![feature(custom_attribute, lang_items)]
#![no_std]

#[macro_use]
mod print;
pub mod lang_items;

const N:usize = 32;

/*precision function*/
/*determinant compute function*/
#[no_mangle]
pub fn det(mut C: [i32; N*N]) -> i64{
    let mut a = [[0i32; N]; N];
    for i in 0..N {
        for j in 0..N {
            a[i][j] = C[i*N+j];
        } 
    }
    let mut mul:i32 = 0;
    let mut Result1:i32 = 1;
    let mut b = [0i32; N];
    
    for i in 0..N {
        b[i] = i as i32;
    }
    
    for i in 0..N {
        if((a[b[i] as usize][i])!=0){
            for j in (i+1)..N{
                if(a[b[j] as usize][i]==0) 
		    {	
			let temp = b[i];
			b[i] = b[j];
			b[j] = temp;
			Result1 = -Result1;
			break;  
		    }
            }
        }
        Result1 = Result1*a[b[i] as usize][i]; 
        
        for j in (i+1)..N{
             mul = a[b[j] as usize][i]/a[b[i] as usize][i]; 
             for k in 0..N{
		 a[b[j] as usize][k] = a[b[j] as usize][k] - a[b[i] as usize][k] * mul;
             }
        }
    }
    return Result1 as i64;
}

