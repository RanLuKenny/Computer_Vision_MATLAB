#include <linux/init.h>            
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/sched.h>

#define D_ARRAY_SIZE 32
#define N 32
#define BUFFER_LENGTH sizeof(int)*D_ARRAY_SIZE*D_ARRAY_SIZE  

static int receive[D_ARRAY_SIZE*D_ARRAY_SIZE];
static int read_times = 250000;

static long count = 0;
static short n = 0;
static long store_results[19];

extern int kdev_open(void);
extern int kdev_release(void);
extern int kdev_read(int *);
extern int kdev_write(long long *, int);
extern int get_no_det_cals(void);

extern int reset_kdummy(void);
extern long long det(int *); //from rust

static int __init kmod_init(void)
{	
	//test_task = kthread_create()
    int ret, j;
    long long ans = 1;
    /////printk(KERN_INFO "Hello from ktest_init");

    kdev_open();

   	/* resetting the kdummy*/
    reset_kdummy();

	/* Read matrices from the device*/
    /////printk(KERN_INFO "Reading from the device...");
	for (j=0; j< read_times; j++){
		ret = kdev_read(receive);       
		if (ret < 0){
			/////printk(KERN_INFO "Failed to read the message from the device.");
		}
		ans = det(receive); //calculation
		count = count + 1;
		printk(KERN_INFO "answer: %lld", ans);
		ret = kdev_write(&ans, sizeof(long long)); 
	}


	/*reading no of determinant calculations*/
	ret = get_no_det_cals();
	printk(KERN_INFO "No of correct calculations = %d", ret);
   
   	kdev_release();
	
   	return 0;
	
}

static void __exit kmod_exit(void)
{
	printk(KERN_INFO "Bye from ktest_exit");

}
/////////////////////////////////////////////////////////////
/*
void swap_(int *a, int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}

bool zero(int a) 
{  
    return (a == 0);  
}

long long det(int C[N*N]) 
{ 
    int a[N][N];
    short i, j, k;
    long long mul;

    for (i=0; i<N; i++){
    	for(j=0; j<N; j++)
	    	a[i][j] = (C[i*N+j]);
    }

    long long Result=1;  
    int b[N];
    
    for(i=0; i<N; i++) 
		b[i]=i;  

    for(i=0; i<N; i++){  
		if(zero(a[b[i]][i])) 
			for(j=i+1; j<N; j++)  
				if(!zero(a[b[j]][i])) 
				{	
					swap_(&b[i], &b[j]); 
					Result=-Result;
					//printk("in DET function");
					break;  
				}  
				Result*=a[b[i]][i]; 
			for(j=i+1; j<N; j++)  
				if(!zero(a[b[j]][i])){  
					mul=a[b[j]][i]/a[b[i]][i]; 
					for(k=i; k<N; k++)  
					a[b[j]][k]-=a[b[i]][k]*mul;  
			}  
	}  
    return Result;  
}
 */
/////////////////////////////////////////////////////////////
module_init(kmod_init);
module_exit(kmod_exit);
 
MODULE_LICENSE("GPL");             
MODULE_AUTHOR("Kenny");      
MODULE_DESCRIPTION("ELEC513_LAB3");
MODULE_VERSION("..."); 
