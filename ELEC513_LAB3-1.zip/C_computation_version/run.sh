make

echo "Rng123!" | sudo -S insmod CC.ko
#echo "Rng123!" | sudo -S insmod CC_m.ko
echo "[INFO] Inserted kernel mod."

echo "[INFO] Calculate."

echo "[INFO] Cleanup."

