/********************/
//C multiple-threads version
//70 threads could use
/********************/
#include <linux/init.h>            
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/sched.h>

#define D_ARRAY_SIZE 32
#define N 32
#define BUFFER_LENGTH sizeof(int)*D_ARRAY_SIZE*D_ARRAY_SIZE  
#define BUFFER_SIZE 250000 //250000 times
#define NUM_THREADS 70 //70threads

static int receive[D_ARRAY_SIZE*D_ARRAY_SIZE];
static struct task_struct* time_run[NUM_THREADS]; //thread
static struct task_struct* time_10; //thread
static struct task_struct* time_180; //thread
static bool brk_all = 0;
static long count = 0;
static short n = 0;
static long store_record[19];
static int K[BUFFER_SIZE][N*N];
static long long answers[BUFFER_SIZE];

extern int kdev_open(void);
extern int kdev_release(void);
extern int kdev_read(int *);
extern int kdev_write(long long *, int);

extern int reset_kdummy(void);
extern int get_no_det_cals(void);

long long det(int C[N*N]); //matrix determinant
void swap_(int *a, int *b);
bool zero(int a);

static int ten_thread(void *data)
{
    for(;;){
		count = 0;
		set_current_state(TASK_INTERRUPTIBLE);
		schedule_timeout(10*HZ);
		store_record[n] = count;
		n = n + 1;
		//printk(KERN_INFO "CNT = %ld\n", CNT);
		if(brk_all == 1)
	    	break;
	}
    return 0;	
}

static int one8zero_thread(void *data)
{
    brk_all = 0;
    set_current_state(TASK_INTERRUPTIBLE);
    schedule_timeout(180*HZ);
    brk_all = 1;
    return 0;
}

static int run_thread(void *data)
{	
   int m; 
   int cnt = *(int*)data;
   int res = BUFFER_SIZE/NUM_THREADS;
   for (m = (cnt)*res; m < (cnt+1)*res; m = m + 1){
	   answers[m] = det(K[m]); 
	   CNT++;
	   if(brk_all == 1){
	       break;
	   }	
   }
   return 0;	
}

static int __init CC_m_init(void)
{
	int ret1;
	printk(KERN_INFO "Hello from ktest_init");
	kdev_open();
    /* resetting the kdummy*/
    reset_kdummy();
	time_10 = kthread_run(ten_thread, NULL, "GOOD_TEN_SECONDS");
	time_180 = kthread_run(one8zero_thread, NULL, "GOOD_TEN_SECONDS");
	while (brk_all == 0){  
	   //time_180 = kthread_run(one8zero_thread, NULL, "GOOD_TEN_SECONDS"); 
	   int i, j;
	   for(i = 0; i < BUFFER_SIZE; i++)//50000
		  {
		  ret1 = kdev_read(receive);
		  for(j = 0; j < N*N; j++){  		
		  	  K[i][j] = receive[j];   
		  }
	   }
	   int idx[NUM_THREADS];
	   //MULTI0-THREADS
	   int k;
	   for(k = 0; k < NUM_THREADS; k++)
	   {
		idx[k] = k;
    		time_run[idx[k]] = kthread_run(run_thread, NULL, "running", &idx[k]);
	   }
	   //WRITE
	   int y;
       for(y = 0; y < BUFFER_SIZE; y++)
	   {
	       ret1 = kdev_write(&answers[y], sizeof(long long)); 	
	   }
	   //if(brk_all == 1) break;
	  	 /*reading no of determinant calculations*/
	   ret1 = get_no_det_cals();
		//printk(KERN_INFO "No of correct calculations = %d", ret);
   
   	   kdev_release();
   	   return 0;
    }
}

static void __exit CC_m_exit(void)
{
	short k = 0;	
	for (k = 0; k < 18; k ++)
	    printk(KERN_INFO "%d: %d",k, store_record[k]);
}
/////////////////////////////////////////////////////////////
void swap_(int *a, int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}

bool zero(int a) 
{  
    return (a == 0);  
}

long long det(int C[N*N]) 
{ 
    int a[N][N];
    short i, j, k;
    long long mul;

    for (i=0; i<N; i++){
    	for(j=0; j<N; j++)
	    	a[i][j] = (C[i*N+j]);
    }

    long long Result=1;  
    int b[N];
    
    for(i=0; i<N; i++) 
		b[i]=i;  

    for(i=0; i<N; i++){  
		if(zero(a[b[i]][i])) 
			for(j=i+1; j<N; j++)  
				if(!zero(a[b[j]][i])) 
				{	
					swap_(&b[i], &b[j]); 
					Result=-Result;
					//printk("in DET function");
					break;  
				}  
				Result*=a[b[i]][i]; 
			for(j=i+1; j<N; j++)  
				if(!zero(a[b[j]][i])){  
					mul=a[b[j]][i]/a[b[i]][i]; 
					for(k=i; k<N; k++)  
					a[b[j]][k]-=a[b[i]][k]*mul;  
			}  
	}  
    return Result;  
}
 
/////////////////////////////////////////////////////////////
module_init(CC_m_init);
module_exit(CC_m_exit);

MODULE_LICENSE("GPL");             
MODULE_AUTHOR("Kenny");      
MODULE_DESCRIPTION("ELEC513_LAB3");
MODULE_VERSION("..."); 
