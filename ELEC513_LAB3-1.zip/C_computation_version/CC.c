//////////////
//single thread version in pure C
//this could run and get the throughput.
//////////////

#include <linux/init.h>            
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/sched.h>

#define D_ARRAY_SIZE 32
#define N 32
#define BUFFER_LENGTH sizeof(int)*D_ARRAY_SIZE*D_ARRAY_SIZE  

static int receive[D_ARRAY_SIZE*D_ARRAY_SIZE];
static int read_times = 250000; //250000 times

static struct task_struct* time_run; //thread
static struct task_struct* time_10; //thread
static struct task_struct* time_180; //thread

static short brk_all = 0;
static long count = 0;
static short n = 0;
static long store_record[19];

extern int kdev_open(void);
extern int kdev_release(void);
extern int kdev_read(int *);
extern int kdev_write(long long *, int);

extern int reset_kdummy(void);
extern int get_no_det_cals(void);

long long det(int C[N*N]); //calculation function
void swap_(int *a, int *b);
bool zero(int a);
void initialize(void);
void end(void);

static int t_10s_thread(void *data)
{
    for(;;){
	count = 0;
	set_current_state(TASK_INTERRUPTIBLE);
	schedule_timeout(10*HZ);
	store_record[n] = count;
	n++;
	if(brk_all == 1)
	    break;	
    }
    return 0;	
}

static int t_180s_thread(void *data)
{
    brk_all = 0;
    set_current_state(TASK_INTERRUPTIBLE);
    schedule_timeout(180*HZ);
    brk_all = 1;
    return 0;
}




static int run(void *data)
{	
	initialize();
	int ret, j;
    long long ans = 1;
    while(brk_all == 0){
	for (j=0; j< read_times; j++){
		ret = kdev_read(receive);       
		if (ret < 0){
			/////printk(KERN_INFO "Failed to read the message from the device.");
		}
		ans = det(receive);
		count++; //record the count for throuput
		/////printk(KERN_INFO "answer: %lld", ans);
		ret = kdev_write(&ans, sizeof(long long)); 
		}
		
    }
	end();
   	return 0;	
}

static int __init CC_init(void)
{
    time_10 = kthread_run(t_10s_thread, NULL, "count for 10s"); //10 seconds thread
    time_run = kthread_run(run, NULL, "read_calculation_write");//running thread	
    time_180 = kthread_run(t_180s_thread, NULL, "count for 180s"); //180 second thread
	return 0; 
}

static void __exit CC_exit(void) //exit and output the throughput report
{
    printk(KERN_INFO "Bye from ktest_exit");
	int iter = 0;	
	for (iter = 0; iter < 18; iter++)
	    printk(KERN_INFO "the %d time numbers: %d", iter, store_record[iter]);
	    //here I havent divided by 10, pls do that, I dont have time to experment anymore.
}
//////////////////////////////////////////////////////////////
void initialize(void){
	kdev_open();

    reset_kdummy();
}

void end(void){
	get_no_det_cals();
  	kdev_release();	
}
/////////////////////////////////////////////////////////////
void swap_(int *a, int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}

long long det(int C[N*N]) 
{ 
    int a[N][N];
    short i, j, k;
    long long mul;

    for (i=0; i<N; i++){
    	for(j=0; j<N; j++)
	    	a[i][j] = (C[i*N+j]);
    }

    long long Result=1;  
    int b[N];
    
    for(i=0; i<N; i++) 
		b[i]=i;  

    for(i=0; i<N; i++){  
		if((a[b[i]][i])==0) 
			for(j=i+1; j<N; j++)  
				if((a[b[j]][i])!=0) 
				{	
					swap_(&b[i], &b[j]); 
					Result=-Result;
					//printk("in DET function");
					break;  
				}  
				Result*=a[b[i]][i]; 
			for(j=i+1; j<N; j++)  
				if((a[b[j]][i])!=0){  
					mul=a[b[j]][i]/a[b[i]][i]; 
					for(k=i; k<N; k++)  
					a[b[j]][k]-=a[b[i]][k]*mul;  
			}  
	}  
    return Result;  
}
 
/////////////////////////////////////////////////////////////
module_init(CC_init);
module_exit(CC_exit);
 
MODULE_LICENSE("GPL");             
MODULE_AUTHOR("Kenny");      
MODULE_DESCRIPTION("ELEC513_LAB3");
MODULE_VERSION("..."); 
