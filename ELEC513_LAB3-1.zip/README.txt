1. use rust nightly intepretor please

this file contains the code and module file for ELEC513_LAB3. authoer is RAN LU(Kenny)

there is a one page report for this lab, please read that. this contains the experience from this lab.

there are two versions code: C and Rust, in two folders. 

both folders have the script file. 

please go to superuser mode and run by './run.sh'

in C_computation_version
=========>CC.c: single thread computation
=========>CC_m.c: multiple thread computaion

in Rust_computation_version
=========>the file is in src folder. module.c is the module build source code.
