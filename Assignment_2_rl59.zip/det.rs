////////////////////////////////////////////////////////
//	ELEC513: Assignment 2
//	Name: RAN LU(Kenny) 
//	NetID: rl59
//	Date: Mar 20
////////////////////////////////////////////////////////
/*Rust libarary used in this program*/
use std::thread; 
use std::time::{Duration, Instant};
use std::thread::sleep;
use std::fs::{File, OpenOptions};
use std::io::{Read, BufReader};
use std::io::{Write, BufWriter};
use std::io::prelude::*;
use std::{slice,mem};

/*all variables used in this program*/
static mut GLOBAL: i32 = 0;	//10 seconds signal
static mut SHUTDOWN: i32 = 0;	//180 seconds signal
static mut ii: i32 = 0;		//count the number of computation
static mut times: i32 = 0;	//count 1 to 18, for 18 data
static mut answer :[i64; Number] = [0i64; Number];	//buffer to store the answer
static mut array :[i32; Number] = [0i32; Number];	//buffer to store the index for avoiding threads conflict
static mut store_matrix :[[i32; N*N]; Number] = [[0i32; N*N]; Number];	//the 2-D buffer to store the read-in matrices 


const N:usize = 32;		//size/order of matrices
const Number:usize = 7000;	//buffer size for the number of matrices read - compute - write at one time
const Threads_number:usize = 70;//how many threads will be used

//static mut answer: Box<[f64]> = Box::new([0.0f64; Number]);
//this function is just a test function, not used in this program
/*fn test_function(c:i32){
    while true{
        //println!("this is for testing {}\n", c);
        if unsafe{SHUTDOWN == 1}
        { 
            break;
        }
    }
}*/
/*ten seconds record a data*/
fn ten_seconds() {
    //generate a data.txt to store the data we want for plotting
    let mut FF = File::create("data.txt").expect("open dummy failed!");
    loop{
        let now = Instant::now();
        unsafe{
            GLOBAL = 0;	//start GLOBAL to 0
	    ii = 0;
        }
        // we sleep for 10 seconds
        sleep(Duration::new(10, 0));

        unsafe{
            GLOBAL = 1; //10 second later, GLOBAL to 1
	    unsafe{times = times + 1}
	    println!("ten seconds:{}",times);
	    println!("Computation numbers:{}",ii);  
        }
	
	//write data into text file
	write!(&mut FF,"\nten seconds:{} Computation numbers:{}", unsafe {times}, unsafe {ii/10});
        println!("{}", now.elapsed().as_secs());
	if unsafe{SHUTDOWN == 1}
        { 
            println!("10 finished allll!!!!"); 
            break;
        }
    }
}

fn ONE_EIGHT_ZERO_seconds() {
    let now = Instant::now();
    unsafe{
        SHUTDOWN = 0;	//initial SHUTDOWN to 0
    }
    // sleep for 180 seconds
    sleep(Duration::new(180, 0));
    unsafe{
	println!("180 finished allll!!!!"); 
        SHUTDOWN = 1;	//change SHUTDOWN to 1
    }
    println!("{}", now.elapsed().as_secs());
}

/*precision function*/
fn zero(a: f64) -> bool{
    return (a > -0.0000001) && (a < 0.0000001);
}

/*determinant compute function*/
fn det(C: [i32; N*N]) -> f64{
    let mut a = [[0.0f64; N]; N];
    for i in 0..N {
        for j in 0..N {
            a[i][j] = C[i*N+j] as f64;
            //println!("a[{}][{}] is :{}\n",i,j,a[i][j]);
        } 
    }
    let mut mul = 0.0;
    let mut Result1 = 1.0;
    let mut b = [0; N];
    
    for i in 0..N {
        b[i] = i as i32;
        //rintln!("b[{}] is :{}\n",i,b[i]);
    }
    
    for i in 0..N {
        if(zero(a[b[i]as usize][i])==true){
            for j in (i+1)..N{
                if(zero(a[b[j] as usize][i])==false) 
		    {	
			let temp = b[i];
			b[i] = b[j];
			b[j] = temp;
			Result1 = -Result1;
			break;  
		    }
            }
        }
        Result1=Result1*a[b[i] as usize][i]; 
        
        for j in (i+1)..N{
             mul = a[b[j] as usize][i]/a[b[i] as usize][i]; 
             for k in 0..N{
		 a[b[j] as usize][k] = a[b[j] as usize][k] - a[b[i] as usize][k]*mul;
             }
        }
    }
    return Result1;
}


fn reset_dummy(){//directly transform from C, reset the dummy
	let mut reset = File::create("/sys/module/dummy/parameters/no_of_reads").expect("open dummy failed!");
	reset.write_all(b"0");
	drop(reset);
	println!("reset finished");
}


fn main()
{
	/*reset the dummy*/
	reset_dummy();
	/*read Number times*/
	//these matrices are used to transfrom data type
	let mut b = [0u8; N*N*4];
	let mut b1 = [0i8; N*N];
	let mut b2 = [0i32; N*N];
	/*open the dummy file*/
	let mut file = OpenOptions::new()
	    .read(true)
	    .write(true)
	    .create(true)
	    .open("/dev/dummychar")
	    .unwrap();
	//10 seconds threads
	let at1 = thread::spawn(||{
            ten_seconds();
    	});

    loop
    {
	//180 seconds threads
	let at2 = thread::spawn(|| {
	    ONE_EIGHT_ZERO_seconds();
	});

	if unsafe{SHUTDOWN==1} //break if 180 seconds arrived
    	{
		break;
    	}
	/*read part*/
	for k in 0..Number
	{
	    file.read(&mut b[..]).expect("read failed");

	    for i in 0..4*N*N
	    {
	        if i%4==0
	        {
	       	    b1[i/4] = b[i] as i8;//because write in u8 type, so only the last 4 bits are valid
	    	    b2[i/4] = b1[i/4] as i32;
	        }
    	    }
		
	    for m in 0..N*N //store the read-in matrices to store buffer
	    {
		unsafe {store_matrix[k][m] = b2[m]}; 
	    }
	}
	    //10 seconds
	//computaion part, the algorithm is same as LAB1
	//divide the array for each thread
	    let res = (Number/Threads_number) as i32; //1000 divided by 4;
	    let mut threads = vec![];	//store the threads
	    for k in 0..Threads_number		      //0,1,2,3
	    {	
		unsafe {array[k] = k as i32}; 		      //0,1,2,3
		/*computation threads defined here*/
		threads.push((thread::spawn(move || {    
		for i in (unsafe {array[k]}*res) as usize..((unsafe {array[k]}+1)*res) as usize
		{
		    unsafe{ii = ii + 1;}	//'ii' is the number of computation
		    //compute the determinant and store the value into answer buffer
		    unsafe{answer[i as usize] = det(store_matrix[i as usize]) as i64;}
		}
		})));
	    }	    
	////////release threads of computation
	    for th in threads
	    {
		th.join().unwrap();
	    }
	//////test output
	//for i in 0..Number
        //{
	//    println!("the result is :{}", unsafe {answer[i as usize]});
        //}
	/////write part
	for i in 0..Number
	{   /*transform the type i64 into u8*/
	    //then write back
	    let bytes: [u8; 8] = unsafe{std::mem::transmute::<i64,[u8; 8]>(answer[i])};
	    file.write(&bytes).expect("write fail!");
	    file.flush().expect("not correct!");
	}	
    }
    at1.join().unwrap();
    //at2.join().unwrap();		
}

